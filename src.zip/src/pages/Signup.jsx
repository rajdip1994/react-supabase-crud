import { useState } from 'react';
import { supabase } from '../supabaseClient';
import { useNavigate, Link } from 'react-router-dom';

function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSignup = async () => {
    const { error } = await supabase.auth.signUp({
      email,
      password
    });

    if (error) {
      alert(error.message);
      return;
    }

    alert("Signup successful");
    navigate('/login');
  };

  return (
    <div className="container mt-5">
      <div className="card p-4 col-md-4 mx-auto">
        <h4>Signup</h4>

        <input className="form-control mb-2" placeholder="Email"
          onChange={(e) => setEmail(e.target.value)} />

        <input type="password" className="form-control mb-2" placeholder="Password"
          onChange={(e) => setPassword(e.target.value)} />

        <button className="btn btn-success w-100" onClick={handleSignup}>
          Signup
        </button>

        <p className="mt-3 text-center">
          Already have account? <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
}

export default Signup;