import { supabase } from '../supabaseClient';
import { useNavigate, Link } from 'react-router-dom';

function Navbar() {
  const navigate = useNavigate();

  const logout = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  return (
    <nav className="navbar navbar-dark bg-dark px-3">
      <span className="navbar-brand">User App</span>

      <div className="d-flex gap-2">
        <Link to="/dashboard" className="btn btn-light btn-sm">
          Dashboard
        </Link>

        <Link to="/users" className="btn btn-light btn-sm">
          Users
        </Link>

        <button className="btn btn-danger btn-sm" onClick={logout}>
          Logout
        </button>
      </div>
    </nav>
  );
}

export default Navbar;